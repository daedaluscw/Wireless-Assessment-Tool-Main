/*******************************************************************
 * This program runs the first report of Assignment 6
 * The program comples a report for the Staff activity 
 * for the period of January 1 - March 31, 2019
 * This program is a modification of the code provided 
 * in the file called Oracle Primer
 * Modified by: Christopher Wells
 * Date: 2019/5/4
 *
 * *******************************************************************/

import java.sql.*;  //Import the java SQL library

class Report1     //Create a new class to encapsulate the program
{
 
 public static void SQLError (Exception e)   //Our function for handling SQL errors
 {
	System.out.println("ORACLE error detected:");
	e.printStackTrace();	
 }

public static void main (String args[])  //The main function

{

 try {                                        //Keep an eye open for errors
       
       String driverName = "oracle.jdbc.driver.OracleDriver";
       Class.forName(driverName);

       System.out.println("Connecting   to Oracle...");  

       String url = "jdbc:oracle:thin:@apollo.ite.gmu.edu:1521:ite10g";
       Connection conn = DriverManager.getConnection(url,"cwells21","ugriku");

       System.out.println("Connected!");
       
       Statement stmt = conn.createStatement();   //Create a new statement
       
       //Now we execute our query and store the results in the myresults object:
       ResultSet myresults = stmt.executeQuery("SELECT S.ENO, S.ENAME, S.TITLE, P.SSN, P.PNAME, AVG( O.PPAY + O.IPAY) AS AVGC, SUM(O.PPAY + O.IPAY) AS TOTALC, COUNT( P.SSN) AS TOTALV FROM STAFF S, VISIT V, PATIENT P, OUTCOME O WHERE S.ENO =V.ENO AND V.SSN=P.SSN AND P.SSN=O.SSN AND O.VDATE=V.VDATE AND ((V.VDATE >= 20190101) AND (V.VDATE <= 20190331))   GROUP BY S.ENO, S.TITLE, S.ENAME, P.PNAME, P.SSN");
	int visitCounter = 0;
	int chargeCounter = 0;
	String temp = "";
	System.out.println(" Employee Activity Report ");
	System.out.println("-----------------------------------------------------------------------------------------------------------------------------------");
	while ( myresults.next())
	{
		 
		if ( temp.equals(myresults.getString("ENO")))
                {
			temp = myresults.getString("TOTALV");
			chargeCounter = Integer.parseInt(temp);
			while ( chargeCounter > 0)
			{
	
        	                System.out.println("  Patent SSN: " + myresults.getString("SSN") + " Patient Name: " + myresults.getString("PNAME") );
				chargeCounter--;
			}
			chargeCounter = 0;
			System.out.println(" Employee Summary " + " Number Of Visits: " + myresults.getString("TOTALV") + " Total Charges: " + myresults.getString("TOTALC") + " Average Charge Per Visit: " + myresults.getString("AVGC"));
                }

		if  ( !temp.equals(myresults.getString("ENO")))	//Test to see if the employee number has changes
		{
			System.out.println("-----------------------------------------------------------------------------------------------------------------------------------");

			System.out.println("Employee Number: " + myresults.getString("ENO")); //If the information has changes then we have to print the new employee info
			System.out.println("Employee Name: " + myresults.getString("ENAME"));
			System.out.println("Employee Title: " + myresults.getString("TITLE"));
			System.out.println("-----------------------------------------------------------------------------------------------------------------------------------");
			temp =  String.valueOf( myresults.getString("ENO"));	//Indicate that the header has been printed
			temp = myresults.getString("TOTALV");
                        chargeCounter = Integer.parseInt(temp);
                        while ( chargeCounter > 0)
                        {

                                System.out.println("  Patent SSN: " + myresults.getString("SSN") + " Patient Name: " + myresults.getString("PNAME") );
                                chargeCounter--;
                        }
                        chargeCounter = 0;
                        System.out.println(" Employee Summary " + " Number Of Visits: " + myresults.getString("TOTALV") + " Total Charges: " + myresults.getString("TOTALC") + " Average Charge Per Visit: " + myresults.getString("AVGC"));

		}
		
	}
      

	//The Second Half the Inactive Doctors
	System.out.println("");
	System.out.println("");

	 ResultSet myresults2 = stmt.executeQuery("(SELECT S.ENO, S.ENAME FROM Visit V, STAFF S WHERE V.ENO=S.ENO) MINUS ( SELECT S.ENO, S.ENAME FROM STAFF S, VISIT V WHERE S.ENO=V.ENO AND ((V.VDATE >= 20190101) AND (V.VDATE <= 20190331)))");
	System.out.println("The Following Staff Memebers Were Not Actve During This Time");
	 while ( myresults2.next())
        {
		//System.out.println("The Following Staff Memebers Were Not Actve During This Time");
		System.out.println(" Employee Number " +  myresults2.getString("ENO") + " Employee Name: " + myresults2.getString("ENAME") );
	}

	
	System.out.println("Closing SQL Connection");
        //chargeCounter = 0;
                                         	  
   	conn.close();  // Close our connection.
       
        }
        catch (Exception e) {SQLError(e);} //if any error occurred in the try..catch block, call the SQLError function
       
                                                      	                       }
                                                      	                       }


/*---------------------------------------------------------------------------------
 * Ths is the modified program for the second half of Assignment 6.
 *
 * Christopher Wells
 * G-00260513
 * CS 450
 * -------------------------------------------------------------------------------*/


import java.sql.*;  //Import the java SQL library

class Report2     //Create a new class to encapsulate the program
{
 
 public static void SQLError (Exception e)   //Our function for handling SQL errors
 {
	System.out.println("ORACLE error detected:");
	e.printStackTrace();	
 }

public static void main (String args[])  //The main function

{

 try {                                        //Keep an eye open for errors
       
       String driverName = "oracle.jdbc.driver.OracleDriver";
       Class.forName(driverName);

       System.out.println("Connecting   to Oracle...");  

       String url = "jdbc:oracle:thin:@apollo.ite.gmu.edu:1521:ite10g";
       Connection conn = DriverManager.getConnection(url,"cwells21","ugriku");

       System.out.println("Connected!");
       
       Statement stmt = conn.createStatement();   //Create a new statement
       
	
       //Now we execute our query and store the results in the myresults object:
       ResultSet myresults = stmt.executeQuery("SELECT P.PNAME, P.SSN, V.VDATE, S.ENO, S.TITLE, S.ENAME, O.PPAY, O.IPAY, D.CHARGE, (D.CHARGE-O.PPAY-O.IPAY) AS BALANCE, SUM(O.PPAY) AS TOTALPPAY, SUM(O.IPAY) AS TOTALIPAY, SUM(D.CHARGE) AS TOTALCHARGE FROM PATIENT P, VISIT V, STAFF S, OUTCOME O, DIAGNOSIS D WHERE P.SSN=V.SSN AND ((V.VDATE >= 20190101) AND ( V.VDATE <= 20190331)) AND S.ENO=V.ENO AND O.VDATE=V.VDATE AND P.SSN=O.SSN AND O.DCODE=D.DCODE AND O.SCODE=D.SCODE GROUP BY P.PNAME, P.SSN, V.VDATE, S.ENO, S.TITLE, S.ENAME, O.PPAY, O.IPAY, D.CHARGE");
       String temp = "";        
       System.out.println("Summary of Patient Billing for Cycle");
	//temp = myresults.getString("P.SSN");	
       while (myresults.next()) //pass to the next row and loop until the last 
       {
		//temp = myresults.getString("P.SSN");
		if ( temp.equals(myresults.getString("SSN")))
		{
			System.out.println("Patient SSN:  " + myresults.getString("SSN") + " Patient Name: " + myresults.getString("PNAME") + " Visited: " + myresults.getString("TITLE") + " " + myresults.getString("ENO") + " " + myresults.getString("ENAME") + " On: " + myresults.getString("VDATE") + " Total Charges: " + myresults.getString("CHARGE") + " Insurance Paid: " + myresults.getString("PPAY") + " Patient Paid: " + myresults.getString("IPAY") + " Remaining Balance: " + myresults.getString("BALANCE"));

		}
		if ( temp.equals(""))
		{
			temp = myresults.getString("SSN");
			System.out.println("--------------------------------------------------------------------------------------------------------------");
			System.out.println("Patient SSN:  " + myresults.getString("SSN") + " Patient Name: " + myresults.getString("PNAME") + " Visited: " + myresults.getString("TITLE") + " " + myresults.getString("ENO") + " " + myresults.getString("ENAME") + " On: " + myresults.getString("VDATE") + " Total Charges: " + myresults.getString("CHARGE") + " Insurance Paid: " + myresults.getString("PPAY") + " Patient Paid: " + myresults.getString("IPAY") + " Remaining Balance: " + myresults.getString("BALANCE"));
		}
		if ( !temp.equals(myresults.getString("SSN")))
		{
			System.out.println( "Patient Summary:");
			System.out.println( "Total Charges: " + myresults.getString("TOTALCHARGE") + " Total Insurace Paid: " + myresults.getString("TOTALPPAY") + " Total Patient Paid: " + myresults.getString("TOTALIPAY"));
			System.out.println( );
			//if ( !myresults.next())
			{
				System.out.println("Patient SSN:  " + myresults.getString("SSN") + " Patient Name: " + myresults.getString("PNAME") + " Visited: " + myresults.getString("TITLE") + " " + myresults.getString("ENO") + " " + myresults.getString("ENAME") + " On: " + myresults.getString("VDATE") + " Total Charges: " + myresults.getString("CHARGE") + " Insurance Paid: " + myresults.getString("PPAY") + " Patient Paid: " + myresults.getString("IPAY") + " Remaining Balance: " + myresults.getString("BALANCE"));
			}
		}
	}


	//The Second Half the Inactive Doctors
	System.out.println("");
	System.out.println("");

	ResultSet myresults2 = stmt.executeQuery("(SELECT P.SSN,P.PNAME FROM PATIENT P, VISIT V WHERE V.SSN=P.SSN) MINUS ( SELECT P.SSN, P.PNAME FROM PATIENT P, VISIT V WHERE V.SSN=P.SSN AND ((V.VDATE >= 20190101) AND (V.VDATE <= 20190331)))");
 	System.out.println("The Following Patients Were Not Actve During This Time");
	while ( myresults2.next())
	{
		//System.out.println("The Following Staff Memebers Were Not Actve During This Time");
		System.out.println(" Patient Number " +  myresults2.getString("SSN") + " Patient Name: " + myresults2.getString("PNAME") );
	}

			 		         						
	System.out.println("Closing SQL Connection");                   	
	
                                           	  
        conn.close();  // Close our connection.
       //
        }
       catch (Exception e) {SQLError(e);} //if any error occurred in the try..catch block, call the SQLError function
       
                                                      	                       }
                                                      	      

