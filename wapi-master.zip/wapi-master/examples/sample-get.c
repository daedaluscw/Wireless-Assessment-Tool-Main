#include "mainskel.c"

int
main(int argc, char *argv[])
{
	return mainskel(argc, argv, 0);
}
